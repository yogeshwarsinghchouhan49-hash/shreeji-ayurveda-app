SHREEJI AYURVEDA - NATIVE ANDROID SOURCE PROJECT

Android Studio project (Kotlin + Jetpack Compose).
Features in this starter:
- Native Android screens and bottom navigation
- Home, category browsing and product search
- Product list and add-to-cart
- Cart quantity controls and total
- Checkout form with WhatsApp order intent
- Basic stock management screen

Important: This is source code, NOT a compiled APK.
Demo limitations: product data and stock are in app memory only; admin screen has no secure login; no cloud database, live order tracking, payment gateway or delivery integration is connected. WhatsApp order intent opens a compatible app; it does not guarantee order acceptance.
Before production use, connect the real product catalogue, store WhatsApp number, address, authenticated admin, backend/database and payment provider.

Build APK:
1. Extract ZIP.
2. Open folder ShreejiAyurveda in Android Studio.
3. Wait for Gradle sync.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Debug APK output: app/build/outputs/apk/debug/app-debug.apk
